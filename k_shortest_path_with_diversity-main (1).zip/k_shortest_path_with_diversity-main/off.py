import sys

top_level_container_dir = "k_shortest_path_with_diversity-main/"

if top_level_container_dir not in sys.path:
    sys.path.insert(0, top_level_container_dir)

import gc
import networkx as nx
import random
import datetime
import numpy as np

from examples import draw_bar_chart, download_and_prepare_graphs
from examples.draw_distribution import draw_time_distribution, draw_num_of_path_distribution
from src.algorithms import FindKSPD, FindKSPD_Yen, FindKSPD_Minus

def run_algorithm(algorithm, G, threshold, k, node_pairs):
    times = []
    num_paths = []

    for src, dest in node_pairs:
        print(f"\nComparing algorithms for SRC: {src}, DEST: {dest}")

        start_time = datetime.datetime.now()
        alg = algorithm(G, threshold)
        result = alg.find_paths(src=src, dest=dest, k=k)
        end_time = datetime.datetime.now()
        execution_time = end_time - start_time

        times.append(execution_time.total_seconds())
        num_paths.append(alg.number_of_paths_explored)


    return times, num_paths

def upload_graph(filepath, num_pairs):
    G = nx.DiGraph()
    with open(filepath) as f:
        for line in f:
            parts = line.split()
            if len(parts) == 3:  # Weighted graph (3 parçalı satır: kaynak, hedef, ağırlık)
                u, v, weight = int(parts[0]), int(parts[1]), float(parts[2])
                G.add_edge(u, v, weight=weight)
            elif len(parts) == 2:  # Unweighted graph (2 parçalı satır: kaynak ve hedef)
                u, v = map(int, parts)
                G.add_edge(u, v, weight=1)  # Ağırlıksız kenarları varsayılan olarak '1' ağırlıkla ekle
            else:
                raise ValueError("Unexpected line format in graph file.")

    node_pairs = []
    for _ in range(num_pairs):
        src = random.choice(list(G.nodes()))
        reachable = list(nx.descendants(G, src))

        while not reachable:
            src = random.choice(list(G.nodes()))
            reachable = list(nx.descendants(G, src))

        dest = random.choice(reachable)
        node_pairs.append((src, dest))

    return G, node_pairs

#%%
download_and_prepare_graphs()

k_to_find = 10
diversity_threshold = 0.6

web_google_path = "/content/graph-data/web-Google.txt"
num_pairs = 20
G, node_pairs = upload_graph(web_google_path, num_pairs)

print(node_pairs)